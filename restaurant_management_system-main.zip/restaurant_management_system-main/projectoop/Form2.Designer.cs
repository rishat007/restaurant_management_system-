﻿namespace projectoop
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.vScrollBar1 = new System.Windows.Forms.VScrollBar();
            this.BottomToolStripPanel = new System.Windows.Forms.ToolStripPanel();
            this.TopToolStripPanel = new System.Windows.Forms.ToolStripPanel();
            this.RightToolStripPanel = new System.Windows.Forms.ToolStripPanel();
            this.LeftToolStripPanel = new System.Windows.Forms.ToolStripPanel();
            this.ContentPanel = new System.Windows.Forms.ToolStripContentPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.printPreviewDialog1 = new System.Windows.Forms.PrintPreviewDialog();
            this.panel1 = new System.Windows.Forms.Panel();
            this.print = new System.Windows.Forms.RichTextBox();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.newtoolStripButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.pastetoolStripButton = new System.Windows.Forms.ToolStripButton();
            this.printtoolStripButton = new System.Windows.Forms.ToolStripButton();
            this.savetoolStripButton = new System.Windows.Forms.ToolStripButton();
            this.cutetoolStripButton = new System.Windows.Forms.ToolStripButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.f16 = new System.Windows.Forms.NumericUpDown();
            this.f15 = new System.Windows.Forms.NumericUpDown();
            this.checkBox11 = new System.Windows.Forms.CheckBox();
            this.checkBox12 = new System.Windows.Forms.CheckBox();
            this.label26 = new System.Windows.Forms.Label();
            this.l16 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.l15 = new System.Windows.Forms.Label();
            this.l14 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.f2 = new System.Windows.Forms.NumericUpDown();
            this.f1 = new System.Windows.Forms.NumericUpDown();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.chefries = new System.Windows.Forms.CheckBox();
            this.label6 = new System.Windows.Forms.Label();
            this.l2 = new System.Windows.Forms.Label();
            this.l1 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.f3 = new System.Windows.Forms.NumericUpDown();
            this.f4 = new System.Windows.Forms.NumericUpDown();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.cheburger = new System.Windows.Forms.CheckBox();
            this.label8 = new System.Windows.Forms.Label();
            this.l4 = new System.Windows.Forms.Label();
            this.l3 = new System.Windows.Forms.Label();
            this.l11 = new System.Windows.Forms.Label();
            this.l8 = new System.Windows.Forms.Label();
            this.l5 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.button7 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.f5 = new System.Windows.Forms.NumericUpDown();
            this.f6 = new System.Windows.Forms.NumericUpDown();
            this.f7 = new System.Windows.Forms.NumericUpDown();
            this.checkBox6 = new System.Windows.Forms.CheckBox();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.chepizza = new System.Windows.Forms.CheckBox();
            this.label11 = new System.Windows.Forms.Label();
            this.l7 = new System.Windows.Forms.Label();
            this.l6 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.f8 = new System.Windows.Forms.NumericUpDown();
            this.f9 = new System.Windows.Forms.NumericUpDown();
            this.f10 = new System.Windows.Forms.NumericUpDown();
            this.chesand = new System.Windows.Forms.CheckBox();
            this.checkBox8 = new System.Windows.Forms.CheckBox();
            this.checkBox9 = new System.Windows.Forms.CheckBox();
            this.l10 = new System.Windows.Forms.Label();
            this.l9 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.f11 = new System.Windows.Forms.NumericUpDown();
            this.f12 = new System.Windows.Forms.NumericUpDown();
            this.f13 = new System.Windows.Forms.NumericUpDown();
            this.chedes = new System.Windows.Forms.CheckBox();
            this.l13 = new System.Windows.Forms.Label();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.checkBox10 = new System.Windows.Forms.CheckBox();
            this.l12 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.f16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.f15)).BeginInit();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.f2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.f1)).BeginInit();
            this.groupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.f3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.f4)).BeginInit();
            this.groupBox7.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.f5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.f6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.f7)).BeginInit();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.f8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.f9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.f10)).BeginInit();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.f11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.f12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.f13)).BeginInit();
            this.SuspendLayout();
            // 
            // vScrollBar1
            // 
            this.vScrollBar1.Location = new System.Drawing.Point(1498, 83);
            this.vScrollBar1.Name = "vScrollBar1";
            this.vScrollBar1.Size = new System.Drawing.Size(17, 744);
            this.vScrollBar1.TabIndex = 9;
            // 
            // BottomToolStripPanel
            // 
            this.BottomToolStripPanel.Location = new System.Drawing.Point(0, 0);
            this.BottomToolStripPanel.Name = "BottomToolStripPanel";
            this.BottomToolStripPanel.Orientation = System.Windows.Forms.Orientation.Horizontal;
            this.BottomToolStripPanel.RowMargin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.BottomToolStripPanel.Size = new System.Drawing.Size(0, 0);
            // 
            // TopToolStripPanel
            // 
            this.TopToolStripPanel.Location = new System.Drawing.Point(0, 0);
            this.TopToolStripPanel.Name = "TopToolStripPanel";
            this.TopToolStripPanel.Orientation = System.Windows.Forms.Orientation.Horizontal;
            this.TopToolStripPanel.RowMargin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.TopToolStripPanel.Size = new System.Drawing.Size(0, 0);
            // 
            // RightToolStripPanel
            // 
            this.RightToolStripPanel.Location = new System.Drawing.Point(0, 0);
            this.RightToolStripPanel.Name = "RightToolStripPanel";
            this.RightToolStripPanel.Orientation = System.Windows.Forms.Orientation.Horizontal;
            this.RightToolStripPanel.RowMargin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.RightToolStripPanel.Size = new System.Drawing.Size(0, 0);
            // 
            // LeftToolStripPanel
            // 
            this.LeftToolStripPanel.Location = new System.Drawing.Point(0, 0);
            this.LeftToolStripPanel.Name = "LeftToolStripPanel";
            this.LeftToolStripPanel.Orientation = System.Windows.Forms.Orientation.Horizontal;
            this.LeftToolStripPanel.RowMargin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.LeftToolStripPanel.Size = new System.Drawing.Size(0, 0);
            // 
            // ContentPanel
            // 
            this.ContentPanel.Size = new System.Drawing.Size(125, 73);
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(100, 23);
            this.label1.TabIndex = 45;
            // 
            // printDocument1
            // 
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
            // 
            // printPreviewDialog1
            // 
            this.printPreviewDialog1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog1.Enabled = true;
            this.printPreviewDialog1.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog1.Icon")));
            this.printPreviewDialog1.Name = "printPreviewDialog1";
            this.printPreviewDialog1.Visible = false;
            this.printPreviewDialog1.Load += new System.EventHandler(this.printPreviewDialog1_Load);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.print);
            this.panel1.Controls.Add(this.toolStrip1);
            this.panel1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel1.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(875, 51);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(321, 381);
            this.panel1.TabIndex = 70;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // print
            // 
            this.print.Location = new System.Drawing.Point(-1, 31);
            this.print.Name = "print";
            this.print.ReadOnly = true;
            this.print.Size = new System.Drawing.Size(319, 344);
            this.print.TabIndex = 6;
            this.print.Text = "";
            this.print.TextChanged += new System.EventHandler(this.printPreviewDialog1_Load);
            // 
            // toolStrip1
            // 
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newtoolStripButton,
            this.toolStripButton2,
            this.toolStripButton1,
            this.pastetoolStripButton,
            this.printtoolStripButton,
            this.savetoolStripButton,
            this.cutetoolStripButton});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Padding = new System.Windows.Forms.Padding(0, 0, 2, 0);
            this.toolStrip1.Size = new System.Drawing.Size(321, 31);
            this.toolStrip1.TabIndex = 5;
            this.toolStrip1.Text = "toolStrip1";
            this.toolStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.toolStrip1_ItemClicked_1);
            // 
            // newtoolStripButton
            // 
            this.newtoolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.newtoolStripButton.Image = global::projectoop.Properties.Resources.open_menu;
            this.newtoolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.newtoolStripButton.Name = "newtoolStripButton";
            this.newtoolStripButton.Size = new System.Drawing.Size(28, 28);
            this.newtoolStripButton.Text = "&open";
            this.newtoolStripButton.Click += new System.EventHandler(this.newToolStripButton_Click);
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton2.Image = global::projectoop.Properties.Resources.save;
            this.toolStripButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.Size = new System.Drawing.Size(28, 28);
            this.toolStripButton2.Text = "&save";
            this.toolStripButton2.Click += new System.EventHandler(this.saveToolStripButton_Click);
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton1.Image = global::projectoop.Properties.Resources.barber;
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(28, 28);
            this.toolStripButton1.Text = "&cute";
            this.toolStripButton1.Click += new System.EventHandler(this.cutToolStripButton_Click);
            // 
            // pastetoolStripButton
            // 
            this.pastetoolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.pastetoolStripButton.Image = global::projectoop.Properties.Resources.paste;
            this.pastetoolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.pastetoolStripButton.Name = "pastetoolStripButton";
            this.pastetoolStripButton.Size = new System.Drawing.Size(28, 28);
            this.pastetoolStripButton.Text = "&paste";
            this.pastetoolStripButton.Click += new System.EventHandler(this.pasteToolStripButton_Click);
            // 
            // printtoolStripButton
            // 
            this.printtoolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.printtoolStripButton.Image = global::projectoop.Properties.Resources.print;
            this.printtoolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.printtoolStripButton.Name = "printtoolStripButton";
            this.printtoolStripButton.Size = new System.Drawing.Size(28, 28);
            this.printtoolStripButton.Text = "toolStripButton3";
            // 
            // savetoolStripButton
            // 
            this.savetoolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.savetoolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.savetoolStripButton.Name = "savetoolStripButton";
            this.savetoolStripButton.Size = new System.Drawing.Size(23, 28);
            this.savetoolStripButton.Text = "toolStripButton2";
            this.savetoolStripButton.Click += new System.EventHandler(this.saveToolStripButton_Click);
            // 
            // cutetoolStripButton
            // 
            this.cutetoolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.cutetoolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.cutetoolStripButton.Name = "cutetoolStripButton";
            this.cutetoolStripButton.Size = new System.Drawing.Size(23, 28);
            this.cutetoolStripButton.Text = "toolStripButton5";
            this.cutetoolStripButton.Click += new System.EventHandler(this.cutToolStripButton_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.groupBox1.Controls.Add(this.f16);
            this.groupBox1.Controls.Add(this.f15);
            this.groupBox1.Controls.Add(this.checkBox11);
            this.groupBox1.Controls.Add(this.checkBox12);
            this.groupBox1.Controls.Add(this.label26);
            this.groupBox1.Controls.Add(this.l16);
            this.groupBox1.Controls.Add(this.label24);
            this.groupBox1.Controls.Add(this.l15);
            this.groupBox1.Controls.Add(this.l14);
            this.groupBox1.Location = new System.Drawing.Point(305, 310);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(278, 122);
            this.groupBox1.TabIndex = 71;
            this.groupBox1.TabStop = false;
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // f16
            // 
            this.f16.Location = new System.Drawing.Point(148, 91);
            this.f16.Name = "f16";
            this.f16.Size = new System.Drawing.Size(50, 27);
            this.f16.TabIndex = 122;
            this.f16.ValueChanged += new System.EventHandler(this.checkBox12_CheckedChanged);
            this.f16.Click += new System.EventHandler(this.checkBox12_CheckedChanged);
            // 
            // f15
            // 
            this.f15.Location = new System.Drawing.Point(147, 58);
            this.f15.Name = "f15";
            this.f15.Size = new System.Drawing.Size(50, 27);
            this.f15.TabIndex = 121;
            this.f15.ValueChanged += new System.EventHandler(this.checkBox11_CheckedChanged);
            this.f15.Click += new System.EventHandler(this.checkBox11_CheckedChanged);
            // 
            // checkBox11
            // 
            this.checkBox11.AutoSize = true;
            this.checkBox11.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox11.ForeColor = System.Drawing.Color.Gold;
            this.checkBox11.Location = new System.Drawing.Point(9, 62);
            this.checkBox11.Name = "checkBox11";
            this.checkBox11.Size = new System.Drawing.Size(49, 21);
            this.checkBox11.TabIndex = 108;
            this.checkBox11.Text = "Tea";
            this.checkBox11.UseVisualStyleBackColor = true;
            this.checkBox11.CheckedChanged += new System.EventHandler(this.checkBox11_CheckedChanged);
            // 
            // checkBox12
            // 
            this.checkBox12.AutoSize = true;
            this.checkBox12.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox12.ForeColor = System.Drawing.Color.Gold;
            this.checkBox12.Location = new System.Drawing.Point(6, 97);
            this.checkBox12.Name = "checkBox12";
            this.checkBox12.Size = new System.Drawing.Size(67, 21);
            this.checkBox12.TabIndex = 109;
            this.checkBox12.Text = "Coffee";
            this.checkBox12.UseVisualStyleBackColor = true;
            this.checkBox12.CheckedChanged += new System.EventHandler(this.checkBox12_CheckedChanged);
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label26.Location = new System.Drawing.Point(211, 124);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(0, 17);
            this.label26.TabIndex = 115;
            // 
            // l16
            // 
            this.l16.AutoSize = true;
            this.l16.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.l16.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.l16.Location = new System.Drawing.Point(212, 95);
            this.l16.Name = "l16";
            this.l16.Size = new System.Drawing.Size(0, 17);
            this.l16.TabIndex = 114;
            this.l16.TextChanged += new System.EventHandler(this.f16_ValueChanged);
            this.l16.Click += new System.EventHandler(this.f16_ValueChanged);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label24.Font = new System.Drawing.Font("Microsoft YaHei UI", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.Color.Snow;
            this.label24.Location = new System.Drawing.Point(118, 15);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(57, 19);
            this.label24.TabIndex = 107;
            this.label24.Text = "Drinks";
            // 
            // l15
            // 
            this.l15.AutoSize = true;
            this.l15.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.l15.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.l15.Location = new System.Drawing.Point(212, 66);
            this.l15.Name = "l15";
            this.l15.Size = new System.Drawing.Size(0, 17);
            this.l15.TabIndex = 6;
            this.l15.TextChanged += new System.EventHandler(this.f15_ValueChanged);
            this.l15.Click += new System.EventHandler(this.f15_ValueChanged);
            // 
            // l14
            // 
            this.l14.AutoSize = true;
            this.l14.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.l14.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.l14.Location = new System.Drawing.Point(212, 41);
            this.l14.Name = "l14";
            this.l14.Size = new System.Drawing.Size(0, 17);
            this.l14.TabIndex = 5;
            this.l14.TextChanged += new System.EventHandler(this.f14_ValueChanged);
            this.l14.Click += new System.EventHandler(this.f14_ValueChanged);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.f2);
            this.groupBox5.Controls.Add(this.f1);
            this.groupBox5.Controls.Add(this.checkBox1);
            this.groupBox5.Controls.Add(this.chefries);
            this.groupBox5.Controls.Add(this.label6);
            this.groupBox5.Controls.Add(this.l2);
            this.groupBox5.Controls.Add(this.l1);
            this.groupBox5.Location = new System.Drawing.Point(12, 40);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(290, 127);
            this.groupBox5.TabIndex = 75;
            this.groupBox5.TabStop = false;
            this.groupBox5.Enter += new System.EventHandler(this.groupBox5_Enter);
            // 
            // f2
            // 
            this.f2.Location = new System.Drawing.Point(135, 84);
            this.f2.Name = "f2";
            this.f2.Size = new System.Drawing.Size(60, 27);
            this.f2.TabIndex = 115;
            this.f2.ValueChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            this.f2.Click += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // f1
            // 
            this.f1.Location = new System.Drawing.Point(135, 46);
            this.f1.Name = "f1";
            this.f1.Size = new System.Drawing.Size(60, 27);
            this.f1.TabIndex = 112;
            this.f1.ValueChanged += new System.EventHandler(this.chefries_CheckedChanged);
            this.f1.Click += new System.EventHandler(this.chefries_CheckedChanged);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox1.ForeColor = System.Drawing.Color.Gold;
            this.checkBox1.Location = new System.Drawing.Point(7, 86);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(90, 21);
            this.checkBox1.TabIndex = 93;
            this.checkBox1.Text = "France Fry";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // chefries
            // 
            this.chefries.AutoSize = true;
            this.chefries.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chefries.ForeColor = System.Drawing.Color.Gold;
            this.chefries.Location = new System.Drawing.Point(7, 47);
            this.chefries.Name = "chefries";
            this.chefries.Size = new System.Drawing.Size(114, 21);
            this.chefries.TabIndex = 92;
            this.chefries.Text = "Fried Chicken ";
            this.chefries.UseVisualStyleBackColor = true;
            this.chefries.CheckedChanged += new System.EventHandler(this.chefries_CheckedChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label6.Font = new System.Drawing.Font("Microsoft YaHei UI", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.Window;
            this.label6.Location = new System.Drawing.Point(103, 20);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(92, 19);
            this.label6.TabIndex = 92;
            this.label6.Text = "Fried Items";
            // 
            // l2
            // 
            this.l2.AutoSize = true;
            this.l2.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.l2.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.l2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.l2.Location = new System.Drawing.Point(208, 88);
            this.l2.Name = "l2";
            this.l2.Size = new System.Drawing.Size(0, 17);
            this.l2.TabIndex = 90;
            this.l2.TextChanged += new System.EventHandler(this.f2_ValueChanged);
            this.l2.Click += new System.EventHandler(this.f2_ValueChanged);
            // 
            // l1
            // 
            this.l1.AutoSize = true;
            this.l1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.l1.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.l1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.l1.Location = new System.Drawing.Point(208, 48);
            this.l1.Name = "l1";
            this.l1.Size = new System.Drawing.Size(0, 17);
            this.l1.TabIndex = 0;
            this.l1.TextChanged += new System.EventHandler(this.f1_ValueChanged);
            this.l1.Click += new System.EventHandler(this.f1_ValueChanged);
            // 
            // groupBox6
            // 
            this.groupBox6.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.groupBox6.Controls.Add(this.f3);
            this.groupBox6.Controls.Add(this.f4);
            this.groupBox6.Controls.Add(this.checkBox2);
            this.groupBox6.Controls.Add(this.cheburger);
            this.groupBox6.Controls.Add(this.label8);
            this.groupBox6.Controls.Add(this.l4);
            this.groupBox6.Controls.Add(this.l3);
            this.groupBox6.Location = new System.Drawing.Point(10, 166);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(290, 111);
            this.groupBox6.TabIndex = 76;
            this.groupBox6.TabStop = false;
            this.groupBox6.Enter += new System.EventHandler(this.groupBox6_Enter);
            // 
            // f3
            // 
            this.f3.Location = new System.Drawing.Point(137, 42);
            this.f3.Name = "f3";
            this.f3.Size = new System.Drawing.Size(60, 27);
            this.f3.TabIndex = 113;
            this.f3.ValueChanged += new System.EventHandler(this.cheburger_CheckedChanged);
            this.f3.Click += new System.EventHandler(this.cheburger_CheckedChanged);
            // 
            // f4
            // 
            this.f4.Location = new System.Drawing.Point(137, 70);
            this.f4.Name = "f4";
            this.f4.Size = new System.Drawing.Size(60, 27);
            this.f4.TabIndex = 114;
            this.f4.ValueChanged += new System.EventHandler(this.checkBox2_CheckedChanged);
            this.f4.Click += new System.EventHandler(this.checkBox2_CheckedChanged);
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox2.ForeColor = System.Drawing.Color.Gold;
            this.checkBox2.Location = new System.Drawing.Point(5, 77);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(120, 21);
            this.checkBox2.TabIndex = 100;
            this.checkBox2.Text = "Chicken Burger";
            this.checkBox2.UseVisualStyleBackColor = true;
            this.checkBox2.CheckedChanged += new System.EventHandler(this.checkBox2_CheckedChanged);
            // 
            // cheburger
            // 
            this.cheburger.AutoSize = true;
            this.cheburger.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cheburger.ForeColor = System.Drawing.Color.Gold;
            this.cheburger.Location = new System.Drawing.Point(5, 50);
            this.cheburger.Name = "cheburger";
            this.cheburger.Size = new System.Drawing.Size(99, 21);
            this.cheburger.TabIndex = 94;
            this.cheburger.Text = "Beef Burger";
            this.cheburger.UseVisualStyleBackColor = true;
            this.cheburger.CheckedChanged += new System.EventHandler(this.cheburger_CheckedChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft YaHei UI", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.Window;
            this.label8.Location = new System.Drawing.Point(133, 20);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(60, 19);
            this.label8.TabIndex = 99;
            this.label8.Text = "Burger";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // l4
            // 
            this.l4.AutoSize = true;
            this.l4.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.l4.ForeColor = System.Drawing.SystemColors.Control;
            this.l4.Location = new System.Drawing.Point(208, 79);
            this.l4.Name = "l4";
            this.l4.Size = new System.Drawing.Size(0, 17);
            this.l4.TabIndex = 91;
            this.l4.TextChanged += new System.EventHandler(this.f4_ValueChanged);
            this.l4.Click += new System.EventHandler(this.f4_ValueChanged);
            // 
            // l3
            // 
            this.l3.AutoSize = true;
            this.l3.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.l3.ForeColor = System.Drawing.SystemColors.Control;
            this.l3.Location = new System.Drawing.Point(208, 42);
            this.l3.Name = "l3";
            this.l3.Size = new System.Drawing.Size(0, 17);
            this.l3.TabIndex = 1;
            this.l3.TextChanged += new System.EventHandler(this.f3_ValueChanged);
            this.l3.Click += new System.EventHandler(this.f3_ValueChanged);
            // 
            // l11
            // 
            this.l11.AutoSize = true;
            this.l11.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.l11.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.l11.Location = new System.Drawing.Point(213, 42);
            this.l11.Name = "l11";
            this.l11.Size = new System.Drawing.Size(0, 17);
            this.l11.TabIndex = 4;
            this.l11.TextChanged += new System.EventHandler(this.f11_ValueChanged);
            this.l11.Click += new System.EventHandler(this.f11_ValueChanged);
            // 
            // l8
            // 
            this.l8.AutoSize = true;
            this.l8.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.l8.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.l8.Location = new System.Drawing.Point(210, 46);
            this.l8.Name = "l8";
            this.l8.Size = new System.Drawing.Size(0, 17);
            this.l8.TabIndex = 3;
            this.l8.TextChanged += new System.EventHandler(this.f8_ValueChanged);
            this.l8.Click += new System.EventHandler(this.f8_ValueChanged);
            // 
            // l5
            // 
            this.l5.AutoSize = true;
            this.l5.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.l5.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.l5.Location = new System.Drawing.Point(210, 52);
            this.l5.Name = "l5";
            this.l5.Size = new System.Drawing.Size(0, 17);
            this.l5.TabIndex = 2;
            this.l5.TextChanged += new System.EventHandler(this.f5_ValueChanged);
            this.l5.Click += new System.EventHandler(this.f5_ValueChanged);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.LightBlue;
            this.button2.Location = new System.Drawing.Point(81, 26);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(97, 30);
            this.button2.TabIndex = 77;
            this.button2.Text = "Reset";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.LightBlue;
            this.button3.Location = new System.Drawing.Point(171, 68);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(93, 28);
            this.button3.TabIndex = 78;
            this.button3.Text = "Total";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.LightBlue;
            this.button5.Location = new System.Drawing.Point(6, 134);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(96, 30);
            this.button5.TabIndex = 80;
            this.button5.Text = "Print";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.TextChanged += new System.EventHandler(this.textBox5_TextChanged);
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.FloralWhite;
            this.label14.Location = new System.Drawing.Point(6, 25);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(96, 17);
            this.label14.TabIndex = 81;
            this.label14.Text = "Cost of Drinks";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.FloralWhite;
            this.label15.Location = new System.Drawing.Point(4, 52);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(125, 17);
            this.label15.TabIndex = 82;
            this.label15.Text = "Cost of Food Items";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.FloralWhite;
            this.label16.Location = new System.Drawing.Point(6, 88);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(29, 17);
            this.label16.TabIndex = 83;
            this.label16.Text = "Vat";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.FloralWhite;
            this.label17.Location = new System.Drawing.Point(4, 117);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(67, 17);
            this.label17.TabIndex = 84;
            this.label17.Text = "Sub Total";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.FloralWhite;
            this.label18.Location = new System.Drawing.Point(4, 150);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(40, 17);
            this.label18.TabIndex = 85;
            this.label18.Text = "Total";
            this.label18.Click += new System.EventHandler(this.label18_Click);
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.textBox1);
            this.groupBox7.Controls.Add(this.textBox5);
            this.groupBox7.Controls.Add(this.textBox4);
            this.groupBox7.Controls.Add(this.textBox3);
            this.groupBox7.Controls.Add(this.textBox2);
            this.groupBox7.Controls.Add(this.label14);
            this.groupBox7.Controls.Add(this.label18);
            this.groupBox7.Controls.Add(this.label15);
            this.groupBox7.Controls.Add(this.label17);
            this.groupBox7.Controls.Add(this.label16);
            this.groupBox7.Location = new System.Drawing.Point(591, 42);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(278, 187);
            this.groupBox7.TabIndex = 86;
            this.groupBox7.TabStop = false;
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(161, 16);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(101, 23);
            this.textBox1.TabIndex = 91;
            // 
            // textBox5
            // 
            this.textBox5.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox5.Location = new System.Drawing.Point(161, 144);
            this.textBox5.Name = "textBox5";
            this.textBox5.ReadOnly = true;
            this.textBox5.Size = new System.Drawing.Size(101, 23);
            this.textBox5.TabIndex = 90;
            this.textBox5.TextChanged += new System.EventHandler(this.textBox5_TextChanged);
            this.textBox5.VisibleChanged += new System.EventHandler(this.textBox5_TextChanged);
            // 
            // textBox4
            // 
            this.textBox4.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox4.Location = new System.Drawing.Point(161, 111);
            this.textBox4.Name = "textBox4";
            this.textBox4.ReadOnly = true;
            this.textBox4.Size = new System.Drawing.Size(101, 23);
            this.textBox4.TabIndex = 89;
            // 
            // textBox3
            // 
            this.textBox3.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3.Location = new System.Drawing.Point(161, 80);
            this.textBox3.Name = "textBox3";
            this.textBox3.ReadOnly = true;
            this.textBox3.Size = new System.Drawing.Size(101, 23);
            this.textBox3.TabIndex = 88;
            this.textBox3.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(161, 46);
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(101, 23);
            this.textBox2.TabIndex = 87;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.button7);
            this.groupBox8.Controls.Add(this.button3);
            this.groupBox8.Controls.Add(this.button6);
            this.groupBox8.Controls.Add(this.button2);
            this.groupBox8.Controls.Add(this.button5);
            this.groupBox8.Location = new System.Drawing.Point(589, 242);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(278, 190);
            this.groupBox8.TabIndex = 87;
            this.groupBox8.TabStop = false;
            this.groupBox8.Enter += new System.EventHandler(this.groupBox8_Enter);
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.LightBlue;
            this.button7.Location = new System.Drawing.Point(3, 77);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(95, 34);
            this.button7.TabIndex = 82;
            this.button7.Text = "Feedback";
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.LightBlue;
            this.button6.Location = new System.Drawing.Point(179, 129);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(93, 29);
            this.button6.TabIndex = 81;
            this.button6.Text = "Exit";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.f5);
            this.groupBox2.Controls.Add(this.f6);
            this.groupBox2.Controls.Add(this.f7);
            this.groupBox2.Controls.Add(this.checkBox6);
            this.groupBox2.Controls.Add(this.checkBox5);
            this.groupBox2.Controls.Add(this.chepizza);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.l7);
            this.groupBox2.Controls.Add(this.l6);
            this.groupBox2.Controls.Add(this.l5);
            this.groupBox2.Location = new System.Drawing.Point(10, 277);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(292, 155);
            this.groupBox2.TabIndex = 89;
            this.groupBox2.TabStop = false;
            this.groupBox2.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // f5
            // 
            this.f5.Location = new System.Drawing.Point(133, 43);
            this.f5.Name = "f5";
            this.f5.Size = new System.Drawing.Size(60, 27);
            this.f5.TabIndex = 115;
            this.f5.ValueChanged += new System.EventHandler(this.chepizza_CheckedChanged);
            this.f5.Click += new System.EventHandler(this.chepizza_CheckedChanged);
            // 
            // f6
            // 
            this.f6.Location = new System.Drawing.Point(133, 76);
            this.f6.Name = "f6";
            this.f6.Size = new System.Drawing.Size(60, 27);
            this.f6.TabIndex = 116;
            this.f6.ValueChanged += new System.EventHandler(this.checkBox5_CheckedChanged);
            this.f6.Click += new System.EventHandler(this.checkBox5_CheckedChanged);
            // 
            // f7
            // 
            this.f7.Location = new System.Drawing.Point(133, 110);
            this.f7.Name = "f7";
            this.f7.Size = new System.Drawing.Size(60, 27);
            this.f7.TabIndex = 113;
            this.f7.ValueChanged += new System.EventHandler(this.checkBox6_CheckedChanged);
            this.f7.Click += new System.EventHandler(this.checkBox6_CheckedChanged);
            // 
            // checkBox6
            // 
            this.checkBox6.AutoSize = true;
            this.checkBox6.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox6.ForeColor = System.Drawing.Color.Gold;
            this.checkBox6.Location = new System.Drawing.Point(8, 113);
            this.checkBox6.Name = "checkBox6";
            this.checkBox6.Size = new System.Drawing.Size(110, 21);
            this.checkBox6.TabIndex = 104;
            this.checkBox6.Text = "Chicken Pizza";
            this.checkBox6.UseVisualStyleBackColor = true;
            this.checkBox6.CheckedChanged += new System.EventHandler(this.checkBox6_CheckedChanged);
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox5.ForeColor = System.Drawing.Color.Gold;
            this.checkBox5.Location = new System.Drawing.Point(8, 77);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(89, 21);
            this.checkBox5.TabIndex = 103;
            this.checkBox5.Text = "Beef Pizza";
            this.checkBox5.UseVisualStyleBackColor = true;
            this.checkBox5.CheckedChanged += new System.EventHandler(this.checkBox5_CheckedChanged);
            // 
            // chepizza
            // 
            this.chepizza.AutoSize = true;
            this.chepizza.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chepizza.ForeColor = System.Drawing.Color.Gold;
            this.chepizza.Location = new System.Drawing.Point(8, 48);
            this.chepizza.Name = "chepizza";
            this.chepizza.Size = new System.Drawing.Size(105, 21);
            this.chepizza.TabIndex = 102;
            this.chepizza.Text = "Cheese Pizza";
            this.chepizza.UseVisualStyleBackColor = true;
            this.chepizza.CheckedChanged += new System.EventHandler(this.chepizza_CheckedChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft YaHei UI", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.SystemColors.Window;
            this.label11.Location = new System.Drawing.Point(133, 23);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(48, 19);
            this.label11.TabIndex = 100;
            this.label11.Text = "Pizza";
            // 
            // l7
            // 
            this.l7.AutoSize = true;
            this.l7.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.l7.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.l7.Location = new System.Drawing.Point(210, 119);
            this.l7.Name = "l7";
            this.l7.Size = new System.Drawing.Size(0, 17);
            this.l7.TabIndex = 93;
            this.l7.Click += new System.EventHandler(this.f7_ValueChanged);
            // 
            // l6
            // 
            this.l6.AutoSize = true;
            this.l6.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.l6.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.l6.Location = new System.Drawing.Point(210, 83);
            this.l6.Name = "l6";
            this.l6.Size = new System.Drawing.Size(0, 17);
            this.l6.TabIndex = 92;
            this.l6.Click += new System.EventHandler(this.f6_ValueChanged);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.f8);
            this.groupBox3.Controls.Add(this.f9);
            this.groupBox3.Controls.Add(this.f10);
            this.groupBox3.Controls.Add(this.chesand);
            this.groupBox3.Controls.Add(this.checkBox8);
            this.groupBox3.Controls.Add(this.checkBox9);
            this.groupBox3.Controls.Add(this.l10);
            this.groupBox3.Controls.Add(this.l9);
            this.groupBox3.Controls.Add(this.label13);
            this.groupBox3.Controls.Add(this.l8);
            this.groupBox3.Location = new System.Drawing.Point(308, 40);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(277, 125);
            this.groupBox3.TabIndex = 90;
            this.groupBox3.TabStop = false;
            // 
            // f8
            // 
            this.f8.Location = new System.Drawing.Point(144, 39);
            this.f8.Name = "f8";
            this.f8.Size = new System.Drawing.Size(60, 27);
            this.f8.TabIndex = 114;
            this.f8.ValueChanged += new System.EventHandler(this.chesand_CheckedChanged);
            this.f8.Click += new System.EventHandler(this.chesand_CheckedChanged);
            // 
            // f9
            // 
            this.f9.Location = new System.Drawing.Point(143, 66);
            this.f9.Name = "f9";
            this.f9.Size = new System.Drawing.Size(60, 27);
            this.f9.TabIndex = 115;
            this.f9.ValueChanged += new System.EventHandler(this.checkBox8_CheckedChanged);
            this.f9.Click += new System.EventHandler(this.checkBox8_CheckedChanged);
            // 
            // f10
            // 
            this.f10.Location = new System.Drawing.Point(143, 92);
            this.f10.Name = "f10";
            this.f10.Size = new System.Drawing.Size(60, 27);
            this.f10.TabIndex = 116;
            this.f10.ValueChanged += new System.EventHandler(this.checkBox9_CheckedChanged);
            this.f10.Click += new System.EventHandler(this.checkBox9_CheckedChanged);
            // 
            // chesand
            // 
            this.chesand.AutoSize = true;
            this.chesand.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chesand.ForeColor = System.Drawing.Color.Gold;
            this.chesand.Location = new System.Drawing.Point(6, 42);
            this.chesand.Name = "chesand";
            this.chesand.Size = new System.Drawing.Size(112, 21);
            this.chesand.TabIndex = 103;
            this.chesand.Text = "Sub Sandwich";
            this.chesand.UseVisualStyleBackColor = true;
            this.chesand.CheckedChanged += new System.EventHandler(this.chesand_CheckedChanged);
            // 
            // checkBox8
            // 
            this.checkBox8.AutoSize = true;
            this.checkBox8.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox8.ForeColor = System.Drawing.Color.Gold;
            this.checkBox8.Location = new System.Drawing.Point(5, 69);
            this.checkBox8.Name = "checkBox8";
            this.checkBox8.Size = new System.Drawing.Size(130, 21);
            this.checkBox8.TabIndex = 104;
            this.checkBox8.Text = "Smoky Sandwich";
            this.checkBox8.UseVisualStyleBackColor = true;
            this.checkBox8.CheckedChanged += new System.EventHandler(this.checkBox8_CheckedChanged);
            // 
            // checkBox9
            // 
            this.checkBox9.AutoSize = true;
            this.checkBox9.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox9.ForeColor = System.Drawing.Color.Gold;
            this.checkBox9.Location = new System.Drawing.Point(5, 101);
            this.checkBox9.Name = "checkBox9";
            this.checkBox9.Size = new System.Drawing.Size(132, 21);
            this.checkBox9.TabIndex = 105;
            this.checkBox9.Text = "Cheese Sandwich";
            this.checkBox9.UseVisualStyleBackColor = true;
            this.checkBox9.CheckedChanged += new System.EventHandler(this.checkBox9_CheckedChanged);
            // 
            // l10
            // 
            this.l10.AutoSize = true;
            this.l10.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.l10.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.l10.Location = new System.Drawing.Point(210, 102);
            this.l10.Name = "l10";
            this.l10.Size = new System.Drawing.Size(0, 17);
            this.l10.TabIndex = 99;
            this.l10.TextChanged += new System.EventHandler(this.f10_ValueChanged);
            this.l10.Click += new System.EventHandler(this.f10_ValueChanged);
            // 
            // l9
            // 
            this.l9.AutoSize = true;
            this.l9.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.l9.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.l9.Location = new System.Drawing.Point(210, 77);
            this.l9.Name = "l9";
            this.l9.Size = new System.Drawing.Size(0, 17);
            this.l9.TabIndex = 98;
            this.l9.TextChanged += new System.EventHandler(this.f9_ValueChanged);
            this.l9.Click += new System.EventHandler(this.f9_ValueChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label13.Font = new System.Drawing.Font("Microsoft YaHei UI", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.SystemColors.Window;
            this.label13.Location = new System.Drawing.Point(113, 19);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(82, 19);
            this.label13.TabIndex = 93;
            this.label13.Text = "Sandwich";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.f11);
            this.groupBox4.Controls.Add(this.f12);
            this.groupBox4.Controls.Add(this.f13);
            this.groupBox4.Controls.Add(this.chedes);
            this.groupBox4.Controls.Add(this.l13);
            this.groupBox4.Controls.Add(this.checkBox4);
            this.groupBox4.Controls.Add(this.checkBox10);
            this.groupBox4.Controls.Add(this.l12);
            this.groupBox4.Controls.Add(this.label21);
            this.groupBox4.Controls.Add(this.l11);
            this.groupBox4.Location = new System.Drawing.Point(305, 166);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(277, 143);
            this.groupBox4.TabIndex = 91;
            this.groupBox4.TabStop = false;
            // 
            // f11
            // 
            this.f11.Location = new System.Drawing.Point(146, 38);
            this.f11.Name = "f11";
            this.f11.Size = new System.Drawing.Size(60, 27);
            this.f11.TabIndex = 117;
            this.f11.ValueChanged += new System.EventHandler(this.chedes_CheckedChanged);
            this.f11.Click += new System.EventHandler(this.chedes_CheckedChanged);
            // 
            // f12
            // 
            this.f12.Location = new System.Drawing.Point(146, 73);
            this.f12.Name = "f12";
            this.f12.Size = new System.Drawing.Size(60, 27);
            this.f12.TabIndex = 118;
            this.f12.ValueChanged += new System.EventHandler(this.checkBox4_CheckedChanged);
            this.f12.Click += new System.EventHandler(this.checkBox4_CheckedChanged);
            // 
            // f13
            // 
            this.f13.Location = new System.Drawing.Point(146, 111);
            this.f13.Name = "f13";
            this.f13.Size = new System.Drawing.Size(60, 27);
            this.f13.TabIndex = 119;
            this.f13.ValueChanged += new System.EventHandler(this.checkBox10_CheckedChanged);
            this.f13.Click += new System.EventHandler(this.checkBox10_CheckedChanged);
            // 
            // chedes
            // 
            this.chedes.AutoSize = true;
            this.chedes.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chedes.ForeColor = System.Drawing.Color.Gold;
            this.chedes.Location = new System.Drawing.Point(10, 42);
            this.chedes.Name = "chedes";
            this.chedes.Size = new System.Drawing.Size(61, 21);
            this.chedes.TabIndex = 106;
            this.chedes.Text = "Misty";
            this.chedes.UseVisualStyleBackColor = true;
            this.chedes.CheckedChanged += new System.EventHandler(this.chedes_CheckedChanged);
            // 
            // l13
            // 
            this.l13.AutoSize = true;
            this.l13.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.l13.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.l13.Location = new System.Drawing.Point(213, 111);
            this.l13.Name = "l13";
            this.l13.Size = new System.Drawing.Size(0, 17);
            this.l13.TabIndex = 106;
            this.l13.TextChanged += new System.EventHandler(this.f13_ValueChanged);
            this.l13.Click += new System.EventHandler(this.f13_ValueChanged);
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox4.ForeColor = System.Drawing.Color.Gold;
            this.checkBox4.Location = new System.Drawing.Point(10, 76);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(121, 21);
            this.checkBox4.TabIndex = 106;
            this.checkBox4.Text = "Chocolate Cake";
            this.checkBox4.UseVisualStyleBackColor = true;
            this.checkBox4.CheckedChanged += new System.EventHandler(this.checkBox4_CheckedChanged);
            // 
            // checkBox10
            // 
            this.checkBox10.AutoSize = true;
            this.checkBox10.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox10.ForeColor = System.Drawing.Color.Gold;
            this.checkBox10.Location = new System.Drawing.Point(10, 111);
            this.checkBox10.Name = "checkBox10";
            this.checkBox10.Size = new System.Drawing.Size(88, 21);
            this.checkBox10.TabIndex = 107;
            this.checkBox10.Text = "Ice-Cream";
            this.checkBox10.UseVisualStyleBackColor = true;
            this.checkBox10.CheckedChanged += new System.EventHandler(this.checkBox10_CheckedChanged);
            // 
            // l12
            // 
            this.l12.AutoSize = true;
            this.l12.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.l12.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.l12.Location = new System.Drawing.Point(213, 77);
            this.l12.Name = "l12";
            this.l12.Size = new System.Drawing.Size(0, 17);
            this.l12.TabIndex = 105;
            this.l12.TextChanged += new System.EventHandler(this.f12_ValueChanged);
            this.l12.Click += new System.EventHandler(this.f12_ValueChanged);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label21.Font = new System.Drawing.Font("Microsoft YaHei UI", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.SystemColors.Window;
            this.label21.Location = new System.Drawing.Point(118, 15);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(69, 19);
            this.label21.TabIndex = 100;
            this.label21.Text = "Dessert ";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft YaHei UI", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.ForeColor = System.Drawing.Color.Gold;
            this.label28.Location = new System.Drawing.Point(514, 9);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(80, 28);
            this.label28.TabIndex = 92;
            this.label28.Text = "MENU";
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(1224, 448);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox8);
            this.Controls.Add(this.groupBox7);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.vScrollBar1);
            this.Font = new System.Drawing.Font("Microsoft YaHei UI", 11.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Name = "Form2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Tag = "";
            this.Text = " ";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.f16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.f15)).EndInit();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.f2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.f1)).EndInit();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.f3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.f4)).EndInit();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.f5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.f6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.f7)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.f8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.f9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.f10)).EndInit();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.f11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.f12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.f13)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.VScrollBar vScrollBar1;
        private System.Windows.Forms.ToolStripPanel BottomToolStripPanel;
        private System.Windows.Forms.ToolStripPanel TopToolStripPanel;
        private System.Windows.Forms.ToolStripPanel RightToolStripPanel;
        private System.Windows.Forms.ToolStripPanel LeftToolStripPanel;
        private System.Windows.Forms.ToolStripContentPanel ContentPanel;
        private System.Windows.Forms.Label label1;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Windows.Forms.PrintPreviewDialog printPreviewDialog1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Label l15;
        private System.Windows.Forms.Label l14;
        private System.Windows.Forms.Label l11;
        private System.Windows.Forms.Label l8;
        private System.Windows.Forms.Label l5;
        private System.Windows.Forms.Label l3;
        private System.Windows.Forms.Label l1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label l2;
        private System.Windows.Forms.Label l4;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label l7;
        private System.Windows.Forms.Label l6;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label l16;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label l10;
        private System.Windows.Forms.Label l9;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label l13;
        private System.Windows.Forms.Label l12;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.CheckBox chefries;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.CheckBox cheburger;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox6;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.CheckBox chepizza;
        private System.Windows.Forms.CheckBox checkBox8;
        private System.Windows.Forms.CheckBox checkBox9;
        private System.Windows.Forms.CheckBox chesand;
        private System.Windows.Forms.CheckBox chedes;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.CheckBox checkBox10;
        private System.Windows.Forms.CheckBox checkBox11;
        private System.Windows.Forms.CheckBox checkBox12;
        private System.Windows.Forms.ToolStripButton savetoolStripButton;
        private System.Windows.Forms.ToolStripButton printtoolStripButton;
        private System.Windows.Forms.ToolStripButton cutetoolStripButton;
        private System.Windows.Forms.ToolStripButton pastetoolStripButton;
        private System.Windows.Forms.ToolStripButton newtoolStripButton;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.RichTextBox print;
        private System.Windows.Forms.NumericUpDown f16;
        private System.Windows.Forms.NumericUpDown f15;
        private System.Windows.Forms.NumericUpDown f9;
        private System.Windows.Forms.NumericUpDown f8;
        private System.Windows.Forms.NumericUpDown f7;
        private System.Windows.Forms.NumericUpDown f1;
        private System.Windows.Forms.NumericUpDown f10;
        private System.Windows.Forms.NumericUpDown f11;
        private System.Windows.Forms.NumericUpDown f12;
        private System.Windows.Forms.NumericUpDown f13;
        private System.Windows.Forms.NumericUpDown f2;
        private System.Windows.Forms.NumericUpDown f3;
        private System.Windows.Forms.NumericUpDown f4;
        private System.Windows.Forms.NumericUpDown f5;
        private System.Windows.Forms.NumericUpDown f6;
    }
}