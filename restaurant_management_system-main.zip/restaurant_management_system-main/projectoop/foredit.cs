﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace projectoop
{
    class foredit
    {
        int id;  
        string item;  
        string aval;  
       
        public int ID  
        {  
            get { return id; }  
            set { id = value; }  
        }  
       
        public string items 
        {  
            get { return item; }  
            set { item = value; }  
        }  
        
        public string avail  
        {  
            get { return aval; }  
            set { aval = value; }  
        }  
        
       
    
    }
}
